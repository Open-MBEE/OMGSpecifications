from gov.nasa.jpl.mbee.mdk.docgen.docbook import DBTable, DBText, DBParagraph, From
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel.Element import getOwner
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.InstanceSpecification
from com.fasterxml.jackson.databind import ObjectMapper
from java.util import List as javaList
from com.nomagic.magicdraw.core import Application, Project

#gets list of MD elements passed to script
ids = scriptInput["DocGenTargets"]
item = ids[0]

#gets all slots on Model
slot = item.getAppliedStereotypeInstance().getSlot()

#finds slim_connections slot
#returns literal string element in a list
for n in slot:
	if str(n.getDefiningFeature().getHumanName())=='Property slim_connections':
		value = n.getValue()

#gets json string
value1 = value[0]
value2 = str(value1.getValue())

#parses json using jackson
mapper = ObjectMapper()
structured = list(mapper.readTree(value2))


#navigates json to find element id, JIRA ticket name and url
elem4 = []
name3 = []
url4 = []
for i in structured:
	#finds element name and stores it in elem4 list
	elem1 = i.findValue("sources")
	elem2 = elem1.findValue("gid")
	elem3 = list(elem2.findValue("path"))
	for n in elem3:
		if n.textValue() != "4c23c983-7b44-4d08-a8ed-aec737a9ca8e":
			elem4.append(n)

	#finds JIRA ticket name and stores it in name3 list
	name1 = i.findValue("targets")
	name2 = name1.findValue("displayName")
	name3.append(name2)

	#finds JIRA url text node and stores it in url5
	url1 = i.findValue("targets")
	url2 = url1.findValue("gid")
	url3 = url2.findValue("path")
	url4.append(url3)

#picks through ugly string to piece together JIRA url
hyper = []
for n in url4:
	junk,first,middle = n.path(1).asText().partition("http")
	extra = middle.split("/")
	extra = extra[0:3]
	hyper.append(first+extra[0]+"//"+extra[2]+"/browse/")

#creates html hyperlink from url
link1 = []
for b in range(len(name3)):
	z = name3[b].asText()
	link1.append("<a href="+hyper[b]+z+">"+z+"</a>")

#gets the current project to find elements from the ids
project1 = Application.getInstance().getProject()

#finds all elements from the ids in the elem4 list
element = []
for z in elem4:
	project2 = project1.getElementByID(z.asText())
	element.append(project2)

#creates list of lists for the body of the table
#cross reference created in the second and third args of DBParagraph
docgenBody = []
for z in range(len(link1)):
	cref = DBParagraph(element[z].getName(),element[z],From.NAME)
	hyperlink = DBParagraph(link1[z])
	docgenBody.append([cref,hyperlink])

#sets headers
docgenHeaders = [[DBParagraph("Model Element"),DBParagraph("JIRA Ticket")]]

#docgen table construction
docGenTable = DBTable()
docGenTable.setBody(docgenBody)
docGenTable.setHeaders(docgenHeaders)
docGenTable.setTitle("Linked JIRA Tickets")

#returns proper docgen output to generate table
scriptOutput = {}
scriptOutput["DocGenOutput"] = [docGenTable]
